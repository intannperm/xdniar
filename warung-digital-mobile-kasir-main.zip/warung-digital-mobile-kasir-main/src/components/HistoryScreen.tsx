
import React, { useState, useEffect } from 'react';
import { storageService } from '@/lib/storage';
import { format } from 'date-fns';
import { ScrollArea } from './ui/scroll-area';

export const HistoryScreen = () => {
  const [transactions, setTransactions] = useState<any[]>([]);

  useEffect(() => {
    loadTransactions();
  }, []);

  const loadTransactions = async () => {
    const storedTransactions = await storageService.getTransactions();
    setTransactions(storedTransactions.reverse());
  };

  return (
    <div className="p-4 h-full">
      <h2 className="text-xl font-bold mb-4">Riwayat Transaksi</h2>
      <ScrollArea className="h-[calc(100vh-8rem)]">
        <div className="space-y-4">
          {transactions.map(transaction => (
            <div key={transaction.id} className="border rounded-lg p-4">
              <div className="flex justify-between mb-2">
                <div className="text-sm text-muted-foreground">
                  {format(new Date(transaction.date), 'dd/MM/yyyy HH:mm')}
                </div>
                <div className="font-bold">
                  Rp {transaction.total.toLocaleString()}
                </div>
              </div>
              <div className="space-y-1">
                {transaction.items.map((item: any) => (
                  <div key={item.productId} className="text-sm flex justify-between">
                    <span>{item.name}</span>
                    <span>{item.quantity} x Rp {item.price.toLocaleString()}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
};
