
import React, { useState, useEffect } from 'react';
import { storageService } from '@/lib/storage';
import { Search, Plus, Minus, ShoppingCart } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';

export const TransactionScreen = () => {
  const [products, setProducts] = useState<any[]>([]);
  const [cart, setCart] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    const storedProducts = await storageService.getProducts();
    setProducts(storedProducts);
  };

  const addToCart = (product: any) => {
    const existingItem = cart.find(item => item.productId === product.id);
    if (existingItem) {
      setCart(cart.map(item => 
        item.productId === product.id 
          ? { ...item, quantity: item.quantity + 1 } 
          : item
      ));
    } else {
      setCart([...cart, { 
        productId: product.id, 
        name: product.name,
        price: product.price, 
        quantity: 1 
      }]);
    }
  };

  const removeFromCart = (productId: string) => {
    setCart(cart.filter(item => item.productId !== productId));
  };

  const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  const checkout = async () => {
    const transaction = {
      id: Date.now().toString(),
      items: cart,
      total,
      date: new Date().toISOString(),
    };

    const transactions = await storageService.getTransactions();
    await storageService.setTransactions([...transactions, transaction]);
    setCart([]);
  };

  return (
    <div className="p-4 h-full flex flex-col">
      <div className="mb-4">
        <div className="relative">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Cari produk..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="flex-1 overflow-auto">
        <div className="grid grid-cols-2 gap-2">
          {products
            .filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()))
            .map(product => (
              <div 
                key={product.id}
                className="p-2 border rounded-lg"
                onClick={() => addToCart(product)}
              >
                <div className="font-medium">{product.name}</div>
                <div className="text-sm text-muted-foreground">
                  Rp {product.price.toLocaleString()}
                </div>
              </div>
            ))}
        </div>
      </div>

      <div className="mt-4 border-t pt-4">
        <div className="space-y-2">
          {cart.map(item => (
            <div key={item.productId} className="flex justify-between items-center">
              <div>
                <div className="font-medium">{item.name}</div>
                <div className="text-sm text-muted-foreground">
                  {item.quantity} x Rp {item.price.toLocaleString()}
                </div>
              </div>
              <Button variant="destructive" size="sm" onClick={() => removeFromCart(item.productId)}>
                <Minus className="h-4 w-4" />
              </Button>
            </div>
          ))}
        </div>
        
        <div className="mt-4 flex justify-between items-center">
          <div className="font-bold">Total:</div>
          <div className="font-bold">Rp {total.toLocaleString()}</div>
        </div>

        <Button 
          className="w-full mt-4" 
          onClick={checkout}
          disabled={cart.length === 0}
        >
          <ShoppingCart className="mr-2 h-4 w-4" />
          Bayar
        </Button>
      </div>
    </div>
  );
};
