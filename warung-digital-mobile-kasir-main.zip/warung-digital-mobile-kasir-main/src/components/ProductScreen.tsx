
import React, { useState, useEffect } from 'react';
import { storageService } from '@/lib/storage';
import { Plus, Edit, Trash } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';

export const ProductScreen = () => {
  const [products, setProducts] = useState<any[]>([]);
  const [newProduct, setNewProduct] = useState({ name: '', price: '', stock: '' });
  const [editingProduct, setEditingProduct] = useState<any>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    const storedProducts = await storageService.getProducts();
    setProducts(storedProducts);
  };

  const handleSave = async () => {
    if (editingProduct) {
      const updatedProducts = products.map(p => 
        p.id === editingProduct.id ? editingProduct : p
      );
      await storageService.setProducts(updatedProducts);
      setProducts(updatedProducts);
    } else {
      const newProductData = {
        id: Date.now().toString(),
        name: newProduct.name,
        price: Number(newProduct.price),
        stock: Number(newProduct.stock),
      };
      await storageService.setProducts([...products, newProductData]);
      setProducts([...products, newProductData]);
    }
    setIsDialogOpen(false);
    setNewProduct({ name: '', price: '', stock: '' });
    setEditingProduct(null);
  };

  const handleDelete = async (id: string) => {
    const updatedProducts = products.filter(p => p.id !== id);
    await storageService.setProducts(updatedProducts);
    setProducts(updatedProducts);
  };

  return (
    <div className="p-4 h-full">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold">Produk</h2>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => {
              setEditingProduct(null);
              setNewProduct({ name: '', price: '', stock: '' });
            }}>
              <Plus className="h-4 w-4 mr-2" />
              Tambah Produk
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingProduct ? 'Edit Produk' : 'Tambah Produk Baru'}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <Input
                placeholder="Nama Produk"
                value={editingProduct ? editingProduct.name : newProduct.name}
                onChange={(e) => editingProduct 
                  ? setEditingProduct({...editingProduct, name: e.target.value})
                  : setNewProduct({...newProduct, name: e.target.value})
                }
              />
              <Input
                type="number"
                placeholder="Harga"
                value={editingProduct ? editingProduct.price : newProduct.price}
                onChange={(e) => editingProduct
                  ? setEditingProduct({...editingProduct, price: e.target.value})
                  : setNewProduct({...newProduct, price: e.target.value})
                }
              />
              <Input
                type="number"
                placeholder="Stok"
                value={editingProduct ? editingProduct.stock : newProduct.stock}
                onChange={(e) => editingProduct
                  ? setEditingProduct({...editingProduct, stock: e.target.value})
                  : setNewProduct({...newProduct, stock: e.target.value})
                }
              />
              <Button className="w-full" onClick={handleSave}>
                {editingProduct ? 'Update' : 'Simpan'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-4">
        {products.map(product => (
          <div key={product.id} className="border rounded-lg p-4 flex justify-between items-center">
            <div>
              <div className="font-medium">{product.name}</div>
              <div className="text-sm text-muted-foreground">
                Rp {product.price.toLocaleString()} | Stok: {product.stock}
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="icon" onClick={() => {
                setEditingProduct(product);
                setIsDialogOpen(true);
              }}>
                <Edit className="h-4 w-4" />
              </Button>
              <Button variant="destructive" size="icon" onClick={() => handleDelete(product.id)}>
                <Trash className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
