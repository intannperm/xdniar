
interface Product {
  id: string;
  name: string;
  price: number;
  stock: number;
}

interface Transaction {
  id: string;
  items: Array<{
    productId: string;
    quantity: number;
    price: number;
  }>;
  total: number;
  date: string;
}

export const storageService = {
  async setProducts(products: Product[]) {
    localStorage.setItem('products', JSON.stringify(products));
  },

  async getProducts(): Promise<Product[]> {
    const value = localStorage.getItem('products');
    return value ? JSON.parse(value) : [];
  },

  async setTransactions(transactions: Transaction[]) {
    localStorage.setItem('transactions', JSON.stringify(transactions));
  },

  async getTransactions(): Promise<Transaction[]> {
    const value = localStorage.getItem('transactions');
    return value ? JSON.parse(value) : [];
  },
};
