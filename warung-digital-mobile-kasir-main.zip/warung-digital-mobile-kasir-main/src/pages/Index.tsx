
import React, { useState } from 'react';
import { TransactionScreen } from '@/components/TransactionScreen';
import { HistoryScreen } from '@/components/HistoryScreen';
import { ProductScreen } from '@/components/ProductScreen';
import { ShoppingCart, ClipboardList, Package } from 'lucide-react';

const Index = () => {
  const [activeTab, setActiveTab] = useState(0);

  const screens = [
    { component: TransactionScreen, icon: ShoppingCart, label: 'Transaksi' },
    { component: HistoryScreen, icon: ClipboardList, label: 'Riwayat' },
    { component: ProductScreen, icon: Package, label: 'Produk' },
  ];

  const CurrentScreen = screens[activeTab].component;

  return (
    <div className="h-screen flex flex-col">
      <div className="flex-1 overflow-hidden">
        <CurrentScreen />
      </div>
      
      <div className="flex justify-around items-center border-t bg-background p-2">
        {screens.map((screen, index) => (
          <button
            key={index}
            className={`flex flex-col items-center p-2 rounded-lg ${
              activeTab === index ? 'text-primary' : 'text-muted-foreground'
            }`}
            onClick={() => setActiveTab(index)}
          >
            <screen.icon className="h-6 w-6" />
            <span className="text-xs mt-1">{screen.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default Index;
